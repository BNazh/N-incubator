//
//  ViewController.swift
//  InVision
//
//  Created by Nazhmeddin Babakhanov on 2/18/18.
//  Copyright © 2018 Nazhmeddin Babakhanov. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var TelefonOrEmailLabel: UITextField!
    
    @IBOutlet weak var PasswordLabel: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        TelefonOrEmailLabel.attributedPlaceholder = NSAttributedString(string: "Введите ваш номер или эл. почту", attributes: [NSAttributedStringKey.foregroundColor: hexStringToUIColor(hex: "31436D")])
         PasswordLabel.attributedPlaceholder = NSAttributedString(string: "Пароль", attributes: [NSAttributedStringKey.foregroundColor: hexStringToUIColor(hex: "31436D")])
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func tapOutside(_ sender: UITapGestureRecognizer) {
        TelefonOrEmailLabel.resignFirstResponder()
        PasswordLabel.resignFirstResponder()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}

