//
//  FrendliestViewController.swift
//  SduInformer
//
//  Created by Nazhmeddin Babakhanov on 2/21/18.
//  Copyright © 2018 Nazhmeddin Babakhanov. All rights reserved.
//

import UIKit

class FrendliestViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
        
        private let cellId = "cellId"
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            navigationItem.title = "Recent"
            
            collectionView?.backgroundColor = UIColor.white
            collectionView?.alwaysBounceVertical = true
            
            collectionView?.register(FriendCell.self, forCellWithReuseIdentifier: cellId)
        }
        
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return 3
        }
        
        override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
            return collectionView.dequeueReusableCell(withReuseIdentifier: cellId, for: indexPath as IndexPath)
        }
        
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: IndexPath) -> CGSize {
            return CGSizeMake(view.frame.width, 100)
        }
    }

    
    
