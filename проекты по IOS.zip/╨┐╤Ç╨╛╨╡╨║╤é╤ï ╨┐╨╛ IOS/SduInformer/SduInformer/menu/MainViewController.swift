//
//  MainViewController.swift
//  SduInformer
//
//  Created by Nazhmeddin Babakhanov on 2/21/18.
//  Copyright © 2018 Nazhmeddin Babakhanov. All rights reserved.
//

import UIKit
import Cartography

class MainViewController: UIViewController {
    var sidebarView: SidebarView!
    var blackScreen: UIView!
//
//    let image:UIImageView = {
//        var imageView = UIImageView(image: #imageLiteral(resourceName: "sdu"))
//        imageView.contentMode =  UIViewContentMode.scaleAspectFill
//        imageView.translatesAutoresizingMaskIntoConstraints = false
//        imageView.clipsToBounds = true
//        return imageView
//    }()
    
    let JustLabel: UITextView = {
        let text = UITextView()
        text.text =  "Университет имени Сулеймана Демиреля — светское высшее образовательное учреждение, расположенное в Алматинской области в городе Каскелен.\nСДУ был открыт 17 декабря 1996 года общественным фондом 'Білім Орда' при участии президента Республики Казахстан Н.А.Назарбаевым и девятым президентом Турции С.Демирелем. По предложению Н.А.Назарбаева университет был назван в честь Сулеймана Демиреля.\nОсновным предметом деятельности университета является реализация образовательных учебных программ высшего, послевузовского образования и организации дополнительного образования для взрослых. Программы университета ориентированы на современные потребности общества, и адаптированы к быстро меняющейся социальной, политической и экономической обстановке в стране. В университете созданы условия для обеспечения доступности и качества образования, отвечающего требованиям международного и национального законодательства, для постоянного повышения квалификации профессорско-преподавательского состава и повышение эффективности управления университетом. Профессорско-преподавательский состав университета осуществляет научные исследования в различных областях знания. Университет предоставляет широкий выбор дополнительных образовательных  услуг.\nДеятельность СДУ направлена на разработку и осуществление образовательных, исследовательских и научных программ таким образом, чтобы предоставить студентам все необходимые навыки, как для профессионального роста, так и для личного развития. Уважение интеллектуального потенциала и достоинства студента как личности, имеют первостепенное значение."
        text.backgroundColor =  UIColor(red: 176/255, green: 190/255, blue: 197/255, alpha: 1)
        text.font = UIFont(name: "TimesNewRomanPS-ItalicMT" , size: 12)
        text.textAlignment = NSTextAlignment.justified
        text.textColor = UIColor(red:94/255, green: 53/255, blue: 177/255, alpha: 1)
        text.translatesAutoresizingMaskIntoConstraints = false
        text.isScrollEnabled = false
        return text
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
        self.title = "Home"
        view.backgroundColor =  UIColor(red: 176/255, green: 190/255, blue: 197/255, alpha: 1)
        //self.view.backgroundColor = UIColor.white
        let btnMenu = UIBarButtonItem(image: #imageLiteral(resourceName: "menu"), style: .plain, target: self, action:  #selector(btnMenuAction))
        btnMenu.tintColor=UIColor(red: 54/255, green: 55/255, blue: 56/255, alpha: 1.0)
        self.navigationItem.leftBarButtonItem = btnMenu
        
        sidebarView=SidebarView(frame: CGRect(x: 0, y: 0, width: 0, height: self.view.frame.height))
        sidebarView.delegate=self
        sidebarView.layer.zPosition=100
        self.view.isUserInteractionEnabled=true
        self.navigationController?.view.addSubview(sidebarView)
        
        blackScreen=UIView(frame: self.view.bounds)
        blackScreen.backgroundColor=UIColor(white: 0, alpha: 0.5)
        blackScreen.isHidden=true
        self.navigationController?.view.addSubview(blackScreen)
        blackScreen.layer.zPosition=99
        let tapGestRecognizer = UITapGestureRecognizer(target: self, action: #selector(blackScreenTapAction(sender:)))
        blackScreen.addGestureRecognizer(tapGestRecognizer)
        
      
        
        let imageView = UIImageView(image: #imageLiteral(resourceName: "sdu"))
        imageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(imageView)
        
        imageView.topAnchor.constraint(equalTo: view.topAnchor,constant:50).isActive = true
        imageView.heightAnchor.constraint(equalToConstant: view.bounds.height/2.8).isActive = true
        imageView.widthAnchor.constraint(equalToConstant: view.bounds.width).isActive = true
        
        
        
        
        view.addSubview(JustLabel)
        
        JustLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor).isActive = true
        JustLabel.widthAnchor.constraint(equalTo: imageView.widthAnchor).isActive = true
        
        
        //JustLabel.topAnchor.constraint(equalTo: view.bottomAnchor,constant:100).isActive = true
        
        
        
        
        
        
//        constrain(verhniView,verhniView1){verhniView,verhniView1 in
//
//            verhniView.height == self.view.bounds.height/2
//            verhniView.width == self.view.bounds.width
//
//            verhniView1.height == verhniView.height
//            verhniView1.width == self.view.bounds.width
//
//
//            distribute(by: 0, vertically: verhniView, verhniView1)
//        }
    }
    
    
    
    
    
    
    
    @objc func btnMenuAction() {
        blackScreen.isHidden=false
        UIView.animate(withDuration: 0.3, animations: {
            self.sidebarView.frame=CGRect(x: 0, y: 0, width: 260, height: self.sidebarView.frame.height)
        }) { (complete) in
            self.blackScreen.frame=CGRect(x: self.sidebarView.frame.width, y: 0, width: self.view.frame.width-self.sidebarView.frame.width, height: self.view.bounds.height+100)
        }
    }
    
    @objc func blackScreenTapAction(sender: UITapGestureRecognizer) {
        blackScreen.isHidden=true
        blackScreen.frame=self.view.bounds
        UIView.animate(withDuration: 0.3) {
            self.sidebarView.frame=CGRect(x: 0, y: 0, width: 0, height: self.sidebarView.frame.height)
        }
    }
    
}
extension MainViewController: SidebarViewDelegate {
    func sidebarDidSelectRow(row: Row) {
        blackScreen.isHidden=true
        blackScreen.frame=self.view.bounds
        UIView.animate(withDuration: 0.3) {
            self.sidebarView.frame=CGRect(x: 0, y: 0, width: 0, height: self.sidebarView.frame.height)
        }
        switch row {
        case .SDU:
            print("SDU")
            self.show(MainViewController(), sender: self)
        case .Faculties:
            print("Faculties")
            self.show(FacultiesController(), sender: self)
        case .Clubs:
            print("Clubs")
            self.show(EditProfileVC(), sender: self)
        case .News:
            print("News")
             self.show(NewsControllerTableViewController(), sender: self)
        case .Contacts:
            print("Contacts")
            self.show(ContactsController(), sender: self)
        case .SocialNetworks:
            print("SocialNetworks")
            self.show(SocialController(), sender: self)
        case .Gallery:
            print("Gallery")
            self.show(ImagesViewController(), sender: self)
        case .Help:
            print("Help")
            self.show(HelpController(), sender: self)
        case .none:
            break
            //        default:  //Default will never be executed
            //            break
            //        }
        }
    }
}
