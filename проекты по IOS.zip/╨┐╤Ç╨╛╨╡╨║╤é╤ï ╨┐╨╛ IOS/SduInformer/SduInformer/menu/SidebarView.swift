//
//  SidebarView.swift
//  SduInformer
//
//  Created by Nazhmeddin Babakhanov on 2/21/18.
//  Copyright © 2018 Nazhmeddin Babakhanov. All rights reserved.
//

import Foundation
import UIKit

class MyTableViewCell: UITableViewCell {
    override func awakeFromNib() {
        super.awakeFromNib()
        layoutMargins = UIEdgeInsetsMake(8, 0, 8, 0)
    }
}
protocol SidebarViewDelegate: class {
    func sidebarDidSelectRow(row: Row)
}

enum Row: String {
    case SDU
    case Faculties
    case Clubs
    case News
    case Contacts
    case SocialNetworks
    case Gallery
    case Help
    case none
    
    
    init(row: Int) {
        switch row {
        case 0 : self = .SDU
        case 1: self = .Faculties
        case 2: self = .Clubs
        case 3: self = .News
        case 4: self = .Contacts
        case 5: self = .SocialNetworks
        case 6: self = .Gallery
        case 7: self = .Help
        default: self = .none
        }
    }
}

class SidebarView: UIView, UITableViewDelegate, UITableViewDataSource {
    
    var titleArr = [String]()
    let dividerLineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(white: 0.5, alpha: 0.5)
        return view
    }()
    weak var delegate: SidebarViewDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor=UIColor(red: 54/255, green: 55/255, blue: 56/255, alpha: 1.0)
        //self.clipsToBounds=true
        
        titleArr = ["SDU","Faculties", "Clubs", "News", "Contacts", "Social networks",  "Gallery", "Help"]
        
        setupViews()
        
        
        myTableView.delegate=self
        myTableView.dataSource=self
        myTableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        myTableView.tableFooterView=UIView()
        myTableView.separatorStyle = UITableViewCellSeparatorStyle.none
        myTableView.backgroundColor = UIColor.init(red: 77/255, green: 77/255, blue: 77/255, alpha: 1)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.backgroundColor = UIColor.init(red: 77/255, green: 77/255, blue: 77/255, alpha: 1)
        cell.layer.borderColor = UIColor.black.cgColor
        //cell.layer.borderWidth = 1
       // cell.layer.cornerRadius = 8
       
        
        
        if indexPath.row == 0 {
            cell.backgroundColor=UIColor(red: 77/255, green: 77/255, blue: 77/255, alpha: 1.0)
            let cellImg = UIImageView(frame: CGRect(x: 50, y:0, width: 100, height: 100))

            cell.addSubview(cellImg)
            cellImg.layer.frame.size = CGSize(width: cell.bounds.width - 100, height: 100)
            cellImg.image=#imageLiteral(resourceName: "logo")
            
        } else {
            cell.textLabel?.text=titleArr[indexPath.row]
            cell.imageView?.image = UIImage(named: titleArr[indexPath.row])
            cell.textLabel?.textColor=UIColor.white
           // cell.translatesAutoresizingMaskIntoConstraints = false
           // cell = UIEdgeInsets(top: CGFloat(20), left: CGFloat(20), bottom: CGFloat(20), right: CGFloat(20))
            //cell.imageView?.layer.frame.size = CGSize(width: cell.bounds.width - 40, height: 120)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.delegate?.sidebarDidSelectRow(row: Row(row: indexPath.row))
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 100
        } else {
            return 50
        }
    }
    
    func setupViews() {
        self.addSubview(myTableView)
        myTableView.topAnchor.constraint(equalTo: topAnchor).isActive=true
        myTableView.leftAnchor.constraint(equalTo: leftAnchor).isActive=true
        myTableView.rightAnchor.constraint(equalTo: rightAnchor).isActive=true
        myTableView.bottomAnchor.constraint(equalTo: bottomAnchor).isActive=true
    }
    
    let myTableView: UITableView = {
        let table=UITableView()
        table.translatesAutoresizingMaskIntoConstraints=false
        return table
    }()
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}




class JustCell: UITableViewCell {
    
    var ttt: UIImageView = {
        let image = UIImageView(image: #imageLiteral(resourceName: "club0"))
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    
    var label: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Nurzhan Master in iOS"
        return label
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupView()
        
    }
    
    func setupView(){
        addSubview(ttt)
        addSubview(label)
        
        //        constrain(ttt, label){ ttt,label in
        //            label.height == 30
        //            label.width == ttt.width
        //
        //            ttt.height ==  300
        //            ttt.width ==  (ttt.superview?.width)!
        //
        //
        //            distribute(by: 10, vertically: ttt,label)
        //        }
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-16-[v0(300)]-8-[v1(30)]-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0":ttt, "v1":label]))
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[v0]|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0":ttt]))
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[v0]|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0":label]))
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
