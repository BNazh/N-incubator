//
//  EditProfileVC.swift
//  SduInformer
//
//  Created by Nazhmeddin Babakhanov on 2/21/18.
//  Copyright © 2018 Nazhmeddin Babakhanov. All rights reserved.
//
extension UILabel {
    func underline() {
        if let textString = self.text {
            let attributedString = NSMutableAttributedString(string: textString)
            attributedString.addAttribute(NSAttributedStringKey.underlineStyle,
                                          value: NSUnderlineStyle.styleSingle.rawValue,
                                          range: NSRange(location: 0, length: attributedString.length - 1))
            attributedText = attributedString
        }
    }
}

import UIKit
class EditProfileVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var titleArr = [String]()
    let profileImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.layer.cornerRadius = 34
        imageView.layer.masksToBounds = true
        return imageView
    }()
    
    let dividerLineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(white: 0.5, alpha: 0.5)
        return view
    }()
    
    let nameLabel: UILabel = {
        let label = UILabel()
        label.text = "Mark Zuckerberg"
        label.font = UIFont.systemFont(ofSize: 18)
        return label
    }()
    
    let messageLabel: UILabel = {
        let label = UILabel()
        label.text = "Your friend's message and something else..."
        label.textColor = UIColor.darkGray
        label.font = UIFont.systemFont(ofSize: 14)
        return label
    }()
    
    let timeLabel: UILabel = {
        let label = UILabel()
        label.text = "12:05 pm"
        label.font = UIFont.systemFont(ofSize: 16)
        label.textAlignment = .right
        return label
    }()
    
    let hasReadImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.layer.cornerRadius = 10
        imageView.layer.masksToBounds = true
        return imageView
    }()
    let myTableView: UITableView = {
        let table=UITableView()
        table.translatesAutoresizingMaskIntoConstraints=false
        return table
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        titleArr = ["Academic club", "ART club", "Debate club", "Enterprice group" , "Домбыра club","Education club","Sana IQ Club","UNITY Dance Club","IT-club","RedCrescent","Мағжан","Орлеан","Шапагат","Enactus","SDU Faces","Music club","Vision","Event club","PandUP","MMDANCE","Motion"]
        //,"Sport club"
        self.view.clipsToBounds = true
        setupViews()
        self.title = "Clubs"
        
        myTableView.delegate=self
        myTableView.dataSource=self
        myTableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        myTableView.tableFooterView=UIView()
        
        myTableView.allowsSelection = true
        myTableView.bounces=false
        myTableView.showsVerticalScrollIndicator=false
        myTableView.backgroundColor = UIColor(red: 54/255, green: 55/255, blue: 56/255, alpha: 1.0)
        myTableView.alwaysBounceVertical = true
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.backgroundColor = UIColor(red: 54/255, green: 55/255, blue: 56/255, alpha: 1.0)
        cell.selectionStyle = .none
        cell.textLabel?.text=titleArr[indexPath.row]
        cell.textLabel?.textColor = UIColor.white
        cell.textLabel?.textAlignment = .center
        
        cell.imageView?.image = UIImage(named:"club\(indexPath.row)")
        cell.imageView?.clipsToBounds = true
        cell.layoutMargins = UIEdgeInsets.zero
        
        
        return cell
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.alpha = 0
        let transform = CATransform3DTranslate(CATransform3DIdentity, -250, 20, 0)
        cell.layer.transform = transform
        
        UIView.animate(withDuration: 1) {
            cell.alpha = 1
            cell.layer.transform = CATransform3DIdentity
        }
    }
    
    
    
    func setupViews() {
        self.view.addSubview(myTableView)
        
        myTableView.topAnchor.constraint(equalTo: view.topAnchor).isActive=true
        myTableView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive=true
        myTableView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive=true
        myTableView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive=true
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.show(ClubsInformation(), sender: self)
    }
    
    
    
}

