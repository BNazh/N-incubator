//
//  NewsControllerTableViewController.swift
//  SduInformer
//
//  Created by Nazhmeddin Babakhanov on 2/25/18.
//  Copyright © 2018 Nazhmeddin Babakhanov. All rights reserved.
//

import UIKit
import Cartography

class NewsControllerTableViewController: UITableViewController {
    
    var articles: [Article] = [
        Article.init("Приглашаем принять участие в научной конференции", "20 февраля 2018 г.", "Nolan", "http://sdu.edu.kz/ru/novosti/2018/02/20/priglashaem-prinyat-uchastie-v-nauchnoj-konferenci/", "informationImage0"),
        Article.init("Приглашаем принять участие в научной конференции", "20 февраля 2018 г.", "Nolan", "http://sdu.edu.kz/ru/novosti/2018/02/20/priglashaem-prinyat-uchastie-v-nauchnoj-konferenci/", "informationImage0"),
        Article.init("Приглашаем принять участие в научной конференции", "20 февраля 2018 г.", "Nolan", "http://sdu.edu.kz/ru/novosti/2018/02/20/priglashaem-prinyat-uchastie-v-nauchnoj-konferenci/", "informationImage0"),
        Article.init("Приглашаем принять участие в научной конференции", "20 февраля 2018 г.", "Nolan", "http://sdu.edu.kz/ru/novosti/2018/02/20/priglashaem-prinyat-uchastie-v-nauchnoj-konferenci/", "informationImage0"),
        Article.init("Приглашаем принять участие в научной конференции", "20 февраля 2018 г.", "Nolan", "http://sdu.edu.kz/ru/novosti/2018/02/20/priglashaem-prinyat-uchastie-v-nauchnoj-konferenci/", "informationImage0"),
        Article.init("Приглашаем принять участие в научной конференции", "20 февраля 2018 г.", "Nolan", "http://sdu.edu.kz/ru/novosti/2018/02/20/priglashaem-prinyat-uchastie-v-nauchnoj-konferenci/", "informationImage0"),
        Article.init("Приглашаем принять участие в научной конференции", "20 февраля 2018 г.", "Nolan", "http://sdu.edu.kz/ru/novosti/2018/02/20/priglashaem-prinyat-uchastie-v-nauchnoj-konferenci/", "informationImage0")
    ]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.title = "News SDU"
        tableView.delegate=self
        tableView.dataSource=self
        tableView.register(UITableViewCell.self , forCellReuseIdentifier: "Cell")
        self.navigationController?.navigationBar.barTintColor = .green
        
       
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return articles.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = articles[indexPath.row].headline
        cell.textLabel?.font = UIFont.init(name: "Helvetica Neue", size: CGFloat(14))
        cell.textLabel?.textAlignment = .center
     
        return cell
    }

}


class NewsCell: UITableViewCell {
    let verhniView = UIView()
    let verhniView1 = UIView()
    
    var NewsImageView: UIImageView = {
        let image = UIImageView(image: #imageLiteral(resourceName: "club0"))
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    
    var timeLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "fasf"
        label.textColor = UIColor.darkGray
        return label
    }()
    
    var titleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont(name:"HelveticaNeue-Bold", size: 12.0)
        label.text = "fassdgsdgf"
        
        return label
    }()
    
    var informationLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "fasf"
        return label
    }()
    
    var autorLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "fasf"
        label.textColor = UIColor.darkGray
        return label
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
        
        
    }
    
    func setupView(){
        addSubview(verhniView)
        addSubview(verhniView1 )
        addSubview(NewsImageView)
        addSubview(informationLabel)
        addSubview(titleLabel)
        addSubview(autorLabel)
        addSubview(timeLabel)
        
        
//        constrain(NewsImageView, messageLabel){ NewsView,messageLabel in
//            
//            NewsView.width == view.bounds.width
//            NewsView.height == (NewsView.superview?.height)!/2
//            NewsView.top == (NewsView.superview?.top)! + 40
//            messageLabel.top == NewsView.bottom
//            messageLabel.width == view.bounds.width
//            
//            distribute(by: 15, vertically:NewsView, messageLabel)
//            
//        }
//        
        
        
        
        constrain(verhniView,verhniView1){verhniView,verhniView1 in
            
            verhniView.height == (verhniView.superview?.height)!
            verhniView.width == (verhniView.superview?.width)!/2.7
            
            verhniView1.height == verhniView.height
            verhniView1.width == (verhniView.superview?.width)! - verhniView.width 
            
            
            distribute(by: 0, horizontally: verhniView, verhniView1)
        }
        
        

    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


