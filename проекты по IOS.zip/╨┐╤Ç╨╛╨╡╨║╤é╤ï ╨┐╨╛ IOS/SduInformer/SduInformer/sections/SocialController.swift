//
//  SocialController.swift
//  SduInformer
//
//  Created by Nazhmeddin Babakhanov on 2/24/18.
//  Copyright © 2018 Nazhmeddin Babakhanov. All rights reserved.
//

import UIKit
import Cartography
class SocialController: UIViewController {
    let button: UIButton = {
        let button = UIButton()
        button.setTitle("Own Instagram", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.backgroundColor = UIColor.init(red: 144/255, green: 144/255, blue: 144/255, alpha: 1.0)
        button.layer.cornerRadius = 10
        button.setTitleColor( .white, for: .normal)
        return button
    }()
    let button1: UIButton = {
        let button = UIButton()
        button.setTitle("Own Facebook", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.backgroundColor = UIColor.init(red: 51/255, green: 87/255, blue: 138/255, alpha: 1.0)
        button.layer.cornerRadius = 10
        button.setTitleColor( .white, for: .normal)
        return button
    }()

    let button2: UIButton = {
        let button = UIButton()
        button.setTitle("Own VK", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.backgroundColor = UIColor.init(red: 76/255, green: 119/255, blue: 166/255, alpha: 1.0)
        button.layer.cornerRadius = 10
        button.setTitleColor( .white, for: .normal)
        return button
    }()
    let button3: UIButton = {
        let button = UIButton()
        button.setTitle("Own Youtube", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.backgroundColor = UIColor.init(red: 252/255, green: 13/255, blue: 28/255, alpha: 1.0)
        button.layer.cornerRadius = 10
        button.setTitleColor( .white, for: .normal)
        return button
    }()
    let button4: UIButton = {
        let button = UIButton()
        button.setTitle("Own Twitter", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.backgroundColor = UIColor.init(red: 42/255, green: 163/255, blue: 239/255, alpha: 1.0)
        button.layer.cornerRadius = 10
        button.setTitleColor( .white, for: .normal)
        return button
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        buttns()
        
        
        
    }
    func buttns(){
        self.view.addSubview(button)
        button.addTarget(self, action: #selector(SocialController.buttonAction(_:)), for: .touchUpInside)
        var imageView : UIImageView!
        imageView = UIImageView(frame: view.bounds)
        imageView.contentMode =  UIViewContentMode.scaleAspectFill
        imageView.clipsToBounds = true
        imageView.image = #imageLiteral(resourceName: "bground")
        imageView.center = view.center
        view.addSubview(imageView)
        self.view.sendSubview(toBack: imageView)
        
        view.addSubview(button)
        button.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -40).isActive = true
        button.heightAnchor.constraint(equalToConstant: 50).isActive = true
        button.topAnchor.constraint(equalTo: view.topAnchor, constant: view.bounds.height/3).isActive = true
        button.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true

        
        self.view.addSubview(button1)
        button.addTarget(self, action: #selector(SocialController.buttonAction1(_:)), for: .touchUpInside)
        
        self.view.addSubview(button2)
        button2.addTarget(self, action: #selector(SocialController.buttonAction2(_:)), for: .touchUpInside)
        
        self.view.addSubview(button3)
        button3.addTarget(self, action: #selector(SocialController.buttonAction3(_:)), for: .touchUpInside)
        
        self.view.addSubview(button4)
        button4.addTarget(self, action: #selector(SocialController.buttonAction3(_:)), for: .touchUpInside)
        
        
        constrain(button,button1,button2,button3,button4){button,button1,button2,button3,button4 in
            button1.width == button.width
            button1.height == button.height
            button1.centerX == button.centerX
            
            button2.width == button.width
            button2.height == button.height
            button2.centerX == button.centerX
            
            
            button3.width == button.width
            button3.height == button.height
            button3.centerX == button.centerX
            
            button4.width == button.width
            button4.height == button.height
            button4.centerX == button.centerX
            
            
            distribute(by: 25, vertically: button,button1, button2,button3,button4)
        }
    }
    
    @objc func buttonAction(_ sender:UIButton!)
    {
       UIApplication.shared.open(URL(string: "https://www.instagram.com/sdukz/")!, options: [:], completionHandler: nil)
    }
   
    @objc func buttonAction1(_ sender:UIButton!)
    {
        UIApplication.shared.open(URL(string: "https://ru-ru.facebook.com/sdukz/")!, options: [:], completionHandler: nil)
    }
    @objc func buttonAction2(_ sender:UIButton!)
    {
        UIApplication.shared.open(URL(string: "https://vk.com/sdukz")!, options: [:], completionHandler: nil)
    }
    @objc func buttonAction3(_ sender:UIButton!)
    {
        UIApplication.shared.open(URL(string: "https://www.youtube.com/channel/UCcNKcO0Ob8tg3s5amHBQoSg")!, options: [:], completionHandler: nil)
    }
    @objc func buttonAction4(_ sender:UIButton!)
    {
        UIApplication.shared.open(URL(string: "https://twitter.com/sdukz")!, options: [:], completionHandler: nil)
    }
    
    
    


}
