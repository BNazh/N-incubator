//
//  MapController.swift
//  SduInformer
//
//  Created by Nazhmeddin Babakhanov on 2/24/18.
//  Copyright © 2018 Nazhmeddin Babakhanov. All rights reserved.
//

import UIKit
import GoogleMaps
import MapKit
import CoreLocation


class MapController: UIViewController , CLLocationManagerDelegate{

    let locationManager = CLLocationManager()
    override func viewDidLoad() {
        
        
    }
    @objc func myLeftSideBarButtonItemTapped(_ sender:UIBarButtonItem!)
    {
        self.show(ContactsController(), sender: self)
    }
    
   
    
        

}
