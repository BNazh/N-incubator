//
//  FacultiesController.swift
//  SduInformer
//
//  Created by Nazhmeddin Babakhanov on 2/22/18.
//  Copyright © 2018 Nazhmeddin Babakhanov. All rights reserved.
//

import UIKit
import Cartography
class FacultiesController: UITableViewController  {

    let profileImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        //imageView.layer.cornerRadius = 34
        imageView.layer.masksToBounds = true
        
        return imageView
    }()
    var mass =  [String]()
    var images_name = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        //self.view.clipsToBounds = true
//        setupViews()
        self.title = "Faculties"
        mass = ["Faculty of jurisprudence and social sciences","Faculty of Pedagogical and Humanitarian sciences","Faculty of Engineering and Natural sciences","Business School SDU","Center for Continuing Education"]
        images_name = ["law","Pedagogical","Engineering","Business","Education"]
        tableView.delegate=self
        tableView.dataSource=self
        tableView.register(CustomCell.self, forCellReuseIdentifier: "Cell")
        //myTableView.tableFooterView=UIView()
        
        tableView.separatorStyle = UITableViewCellSeparatorStyle.none
        //myTableView.allowsSelection = true
       // myTableView.bounces=false
        //myTableView.showsVerticalScrollIndicator=false
        tableView.backgroundColor = UIColor(red: 54/255, green: 55/255, blue: 56/255, alpha: 1.0)
       // myTableView.alwaysBounceVertical = true
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mass.count
    }
    
    
    
    

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! CustomCell
        //cell.layoutMargins = UIEdgeInsets.zero
//        cell.textLabel?.text = mass[indexPath.row]
//        cell.textLabel?.font = UIFont.init(name: "Helvetica Neue", size: CGFloat(14))
        cell.label.text = mass[indexPath.row]
        cell.label.font = UIFont.init(name: "Helvetica Neue", size: CGFloat(14))
        cell.label.textAlignment = .center
        cell.backgroundColor = UIColor.darkGray
        cell.label.textColor = UIColor.white
        cell.ttt.image =  UIImage(named:images_name[indexPath.row])
        //cell.translatesAutoresizingMaskIntoConstraints = false
        //imageView.topAnchor.constraint(equalTo: (cell.textLabel?.topAnchor)!, constant: 20).isActive = true
        //imageView.widthAnchor.constraint(equalToConstant: 200).isActive = true
       // imageView.heightAnchor.constraint(equalToConstant: 200).isActive = true
       // cell.textLabel?.topAnchor.constraint(equalTo:(cell.textLabel?.topAnchor)! , constant: 20).isActive = true
       
        return cell
    }
}


class CustomCell: UITableViewCell {
    
    var ttt: UIImageView = {
        let image = UIImageView(image: #imageLiteral(resourceName: "club0"))
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    
    var label: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Nurzhan Master in iOS"
        return label
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupView()
        
    }
    
    func setupView(){
        addSubview(ttt)
        addSubview(label)
        
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-16-[v0(300)]-8-[v1(30)]-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0":ttt, "v1":label]))
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[v0]|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0":ttt]))
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[v0]|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0":label]))
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}














