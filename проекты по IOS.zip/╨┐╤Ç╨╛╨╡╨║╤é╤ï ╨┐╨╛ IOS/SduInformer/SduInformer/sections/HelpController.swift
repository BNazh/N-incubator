//
//  HelpController.swift
//  SduInformer
//
//  Created by Nazhmeddin Babakhanov on 2/24/18.
//  Copyright © 2018 Nazhmeddin Babakhanov. All rights reserved.
//

import UIKit
import Cartography
class HelpController: UIViewController {
    let NewsView: UIImageView = {
        let view = UIImageView()
    
        view.image = #imageLiteral(resourceName: "iam")
        return view
    }()
    let NewsView1: UIImageView = {
        let view = UIImageView()
        
        view.image = #imageLiteral(resourceName: "ias2")
        return view
    }()
    let nameLabel: UILabel = {
        let label = UILabel()
        label.text = "Nolan Corporation"
        label.textColor = .white
        label.font = UIFont(name: "Bradley Hand", size: 30)
        return label
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        
        view.addSubview(nameLabel)
        view.addSubview(NewsView)
        view.addSubview(NewsView1)
        

        NewsView.translatesAutoresizingMaskIntoConstraints = false
        NewsView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.5).isActive = true
        NewsView.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        
        
        NewsView1.translatesAutoresizingMaskIntoConstraints = false
        NewsView1.topAnchor.constraint(equalTo: NewsView.bottomAnchor).isActive  = true
        NewsView1.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.4).isActive = true
        NewsView1.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        
        
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.topAnchor.constraint(equalTo: NewsView1.bottomAnchor,constant:20).isActive  = true
        nameLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
    }
    
  
    


}
