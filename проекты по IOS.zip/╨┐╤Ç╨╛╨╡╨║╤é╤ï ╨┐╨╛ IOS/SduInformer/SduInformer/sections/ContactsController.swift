//
//  ContactsController.swift
//  SduInformer
//
//  Created by Nazhmeddin Babakhanov on 2/23/18.
//  Copyright © 2018 Nazhmeddin Babakhanov. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Cartography
import GoogleMaps

class ContactsController: UIViewController, CLLocationManagerDelegate{
    var mapView = MKMapView()
    
    let messageLabel: UILabel = {
        let label = UILabel()
        label.text = "● ул. Абылай хана 1/1"
        label.textColor = UIColor.darkGray
        label.font = UIFont(name: "HoeflerText-Italic", size: 23)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    let NewsView: UIImageView = {
        let view = UIImageView()
        view.image = #imageLiteral(resourceName: "map")
        return view
    }()
    
    let messageLabel1: UILabel = {
        let label = UILabel()
        label.text = "● Алматинская обл., Карасайский р-н"
        label.textColor = UIColor.darkGray
        label.font = UIFont(name: "HoeflerText-Italic", size: 23)
         label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    let messageLabel3: UILabel = {
        let label = UILabel()
        label.text = "● г. Каскелен,040900, Казахстан"
        label.textColor = UIColor.darkGray
        label.font = UIFont(name: "HoeflerText-Italic", size: 23)
         label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    let messageLabel4: UILabel = {
        let label = UILabel()
        label.text = "● Тел: +7 727 307 95 60/65 (220, 231, 455)"
        label.textColor = UIColor.darkGray
        label.font = UIFont(name: "HoeflerText-Italic", size: 23)
         label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    let messageLabel5: UILabel = {
        let label = UILabel()
        label.text = "● Моб: + 7 702 000 11 33 (whatsapp)"
        label.textColor = UIColor.darkGray
        label.font = UIFont(name: "HoeflerText-Italic", size: 23)
         label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    let messageLabel6: UILabel = {
        let label = UILabel()
        label.text = "● Факс: +7 727 307 95 58"
        label.textColor = UIColor.darkGray
        label.font = UIFont(name: "HoeflerText-Italic", size: 23)
         label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    let messageLabel7: UILabel = {
        let label = UILabel()
        label.text = "● e-mail: info@sdu.edu.kz"
        label.textColor = UIColor.darkGray
        label.font = UIFont(name: "HoeflerText-Italic", size: 23)
         label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    var tapGesture = UITapGestureRecognizer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
        
        
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(ContactsController.myviewTapped(_:)))
        tapGesture.numberOfTapsRequired = 1
        tapGesture.numberOfTouchesRequired = 1
        NewsView.addGestureRecognizer(tapGesture)
        NewsView.isUserInteractionEnabled = true
    }
    @objc func myviewTapped(_ sender: UITapGestureRecognizer) {
        let latitude:CLLocationDegrees = 43.208109
        let longitude:CLLocationDegrees = 76.669381
        let regionDistance:CLLocationDistance = 1000;
        let coordinates = CLLocationCoordinate2DMake(latitude, longitude)
        let regionSpan = MKCoordinateRegionMakeWithDistance(coordinates, regionDistance, regionDistance)
        
        let options = [MKLaunchOptionsMapCenterKey: NSValue(mkCoordinate: regionSpan.center), MKLaunchOptionsMapSpanKey: NSValue(mkCoordinateSpan: regionSpan.span)]
        
        let placemark = MKPlacemark(coordinate: coordinates)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = "My House"
        mapItem.openInMaps(launchOptions: options)
    }
    
    
    func setupViews() {
        view.addSubview(messageLabel)
        view.addSubview(messageLabel1)
        view.addSubview(messageLabel3)
        view.addSubview(messageLabel4)
        view.addSubview(messageLabel5)
        view.addSubview(messageLabel6)
        view.addSubview(messageLabel7)
        
        view.addSubview(NewsView)
        
        
       
        
        
        constrain(NewsView, messageLabel){ NewsView,messageLabel in
            
            NewsView.width == view.bounds.width
            NewsView.height == (NewsView.superview?.height)!/2
            NewsView.top == (NewsView.superview?.top)! + 40
            messageLabel.top == NewsView.bottom
            messageLabel.width == view.bounds.width
            
            distribute(by: 15, vertically:NewsView, messageLabel)
            
        }
        
        NewsView.frame = mapView.frame
        constrain(messageLabel,messageLabel1,messageLabel3,messageLabel4,messageLabel5,messageLabel6,messageLabel7){messageLabel,messageLabel1,messageLabel3,messageLabel4,messageLabel5,messageLabel6,messageLabel7 in

            messageLabel1.top == messageLabel.bottom
            messageLabel1.width == view.bounds.width
            messageLabel3.width == messageLabel1.width
            messageLabel4.width == messageLabel1.width
            messageLabel5.width == messageLabel1.width
            messageLabel6.width == messageLabel1.width
            messageLabel7.width == messageLabel1.width

            distribute(by: 15, vertically: messageLabel,messageLabel1,messageLabel3,messageLabel4,messageLabel5,messageLabel6,messageLabel7)

        }
        
    }
 
    

}

