//
//  Page.swift
//  SduInformer
//
//  Created by Nazhmeddin Babakhanov on 2/21/18.
//  Copyright © 2018 Nazhmeddin Babakhanov. All rights reserved.
//

import Foundation

struct Page {
    let title: String
    let message: String
    let imageName: String
}

