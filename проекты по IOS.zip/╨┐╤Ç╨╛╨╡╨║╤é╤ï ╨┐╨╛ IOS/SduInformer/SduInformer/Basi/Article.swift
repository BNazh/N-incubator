//
//  Article.swift
//  SduInformer
//
//  Created by Nazhmeddin Babakhanov on 3/5/18.
//  Copyright © 2018 Nazhmeddin Babakhanov. All rights reserved.
//


import UIKit

class Article {
    
    var headline: String?
    var time: String?
    var author: String?
    var url: String?
    var imageUrl: String?
    init(_ headline:String,_ time: String, _ author: String, _ url: String, _ imageUrl: String){
        self.headline = headline
        self.time = time
        self.author = author
        self.url = url
        self.imageUrl = imageUrl
    }
}

