//
//  CustomViewCell.swift
//  Brow
//
//  Created by Nazhmeddin Babakhanov on 2/14/18.
//  Copyright © 2018 Nazhmeddin Babakhanov. All rights reserved.
//

import UIKit

class CustomViewCell: UITableViewCell {
    @IBOutlet weak var RowName: UILabel!
    @IBOutlet weak var time: UILabel!
}
